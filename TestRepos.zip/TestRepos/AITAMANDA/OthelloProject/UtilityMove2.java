public class UtilityMove2 {
    private int utility;
    private Position move;

    UtilityMove2(int utility, Position position) {
        this.utility = utility;
        position = move;
    }

    public int getUtility() {
        return utility;
    }

    public Position getMove() {
        return move;
    }
}