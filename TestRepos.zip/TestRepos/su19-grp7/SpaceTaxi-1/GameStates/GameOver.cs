using System.IO;
using System.Runtime.Remoting.Messaging;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.State;
using SpaceTaxi_1.SpaceTaxiStates;

namespace SpaceTaxi_1.GameStates {
    public class GameOver: IGameState {
        private static GameOver instance;
        private int activeMenuButton;
        private Text GameOverText;
        private Entity backGroundImage;
        private int maxMenuButtons = 2;
        private Text[] menuButtons = new Text[2];
        
        public void GameLoop() {
        }

        public void InitializeGameState() {
        }

        public void UpdateGameLogic() {
        }

        public void RenderState() {
            backGroundImage = new Entity(new DynamicShape(new Vec2F(0.0f,0.0f),
                new Vec2F(1f,1f) ),new Image(Path.Combine("Assets","Images","TitleImage.png")));
            backGroundImage.RenderEntity();
            GameOverText = new Text("GAME OVER", new Vec2F(0.2f,0.5f), new Vec2F(0.4f,0.4f));
            GameOverText.SetColor(new Vec3F(0.99f,0f,0f));
            menuButtons[0] = new Text("Main Menu",new Vec2F(0.5f,0.5f),new Vec2F(0.2f,0.2f) );
            menuButtons[1] = new Text("Exit Game",new Vec2F(0.5f,0.3f),new Vec2F(0.2f,0.2f) );
            for (int i = 0; i < 2; i++) {
                if (i == activeMenuButton) {
                    menuButtons[i].SetColor(new Vec3F(0f,0.99f,0f));
                } else {
                    menuButtons[i].SetColor(new Vec3F(0.99f,0f,0f));
                }
                menuButtons[i].RenderText();
            }
            GameOverText.RenderText();
        }

        public void HandleKeyEvent(string keyValue, string keyAction) {
            if (keyAction == "KEY_PRESS") {
                if (keyValue == "KEY_ENTER") {
                    switch (activeMenuButton) {
                    case 0:
                        SpaceTaxiBus.GetBus().RegisterEvent(
                            GameEventFactory<object>.CreateGameEventForAllProcessors(
                                GameEventType.GameStateEvent,
                                this,
                                "CHANGE_STATE",
                                "MAIN_MENU", ""));
                        break;

                    case 1:
                        SpaceTaxiBus.GetBus().RegisterEvent(
                            GameEventFactory<object>.CreateGameEventForAllProcessors(
                                GameEventType.WindowEvent,
                                this,
                                "CLOSE_WINDOW",
                                "", ""));
                        break;
                    }
                } else if (keyValue == "KEY_UP") {
                    if (activeMenuButton == 0) {
                        activeMenuButton = 1;
                    } else {
                        activeMenuButton += -1;
                    }
                } else if (keyValue == "KEY_DOWN") {
                    if (activeMenuButton == 1) {
                        activeMenuButton = 0;
                    } else {
                        activeMenuButton += 1;
                    }
                }
            }
        }
        public static GameOver GetInstance(){
            return GameOver.instance ?? (GameOver.instance = new GameOver());
        }
    }
}

