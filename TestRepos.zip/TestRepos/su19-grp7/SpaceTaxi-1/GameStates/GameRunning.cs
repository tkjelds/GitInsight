using System;
using System.Collections.Generic;
using System.IO;
using DIKUArcade;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.Physics;
using DIKUArcade.State;
using SpaceTaxi_1.Parser;
using SpaceTaxi_1.SpaceTaxiStates;

namespace SpaceTaxi_1.GameStates {
    public class  GameRunning : IGameState {
        private static GameRunning instance;
        private Entity backGroundImage = new Entity(
            new StationaryShape(new Vec2F(0.0f, 0.0f), new Vec2F(1.0f, 1.0f)),
            new Image(Path.Combine("Assets", "Images", "SpaceBackground.png"))
        );
        private EntityContainer<Entity> Foreground;
        private List<Entity> ForegroundPlatform;
        private ForegroundCreator foregroundCreator = new ForegroundCreator();
        private Player player = new Player();
        private Collision.Collision collision = new Collision.Collision();

        public GameRunning() {
            InitializeGameState();
        }

        public void GameLoop() {
        }

        public void InitializeGameState() {
            Foreground = new EntityContainer<Entity>();
            ForegroundPlatform = new List<Entity>();
            Foreground = foregroundCreator.EntityListCreator("the-beach.txt");
            ForegroundPlatform = foregroundCreator.PlatformListCreator("the-beach.txt");
            if (LevelSelect.CurrentLevel != null) {
                Foreground = LevelSelect.CurrentLevel;
                ForegroundPlatform = LevelSelect.CurrentLevelPlatform;

            }

            player.SetPosition(0.45f, 0.6f);
            player.SetExtent(0.1f, 0.1f);
        }

        public void UpdateGameLogic() {
            player.Move();

        }

        public void RenderState() {

            backGroundImage.RenderEntity();
            foreach (Entity obj in Foreground) {
                obj.RenderEntity();
            }
            foreach (var obj in ForegroundPlatform) {
                obj.RenderEntity();
            }

            player.RenderPlayer();
            collision.ObjectCollision(player,Foreground);
        }

        public void HandleKeyEvent(string keyValue, string keyAction) {
            if (keyAction == "KEY_PRESS") {
                switch (keyValue) {
                case "KEY_ESCAPE":
                    SpaceTaxiBus.GetBus().RegisterEvent(
                        GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.GameStateEvent, this, "CHANGE_STATE", "GAME_PAUSED", ""));
                    break;
                case "KEY_UP":
                    SpaceTaxiBus.GetBus().RegisterEvent(
                        GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.PlayerEvent, this, "BOOSTER_UPWARDS", "", ""));
                    break;
                case "KEY_LEFT":
                    player.Direction(new Vec2F(-0.01f, 0.0f));
                    SpaceTaxiBus.GetBus().RegisterEvent(
                        GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.PlayerEvent, this, "BOOSTER_TO_LEFT", "", ""));
                    break;
                case "KEY_RIGHT":
                    player.Direction(new Vec2F(0.01f, 0.0f));
                    SpaceTaxiBus.GetBus().RegisterEvent(
                        GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.PlayerEvent, this, "BOOSTER_TO_RIGHT", "", ""));
                    break;
                }
            } else if (keyAction == "KEY_RELEASE") {
                switch (keyValue) {
                case "KEY_LEFT":
                    player.Direction(new Vec2F(0.0f, 0.0f));
                    SpaceTaxiBus.GetBus().RegisterEvent(
                        GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.PlayerEvent, this, "STOP_ACCELERATE_LEFT", "", ""));
                    break;
                case "KEY_RIGHT":
                    player.Direction(new Vec2F(0.0f, 0.0f));
                    SpaceTaxiBus.GetBus().RegisterEvent(
                        GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.PlayerEvent, this, "STOP_ACCELERATE_RIGHT", "", ""));
                    break;
                case "KEY_UP":
                    SpaceTaxiBus.GetBus().RegisterEvent(
                        GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.PlayerEvent, this, "STOP_ACCELERATE_UP", "", ""));
                    break;
                }
            }
        }
        


        public static GameRunning GetInstance() {
            return GameRunning.instance ?? (GameRunning.instance = new GameRunning());
        }
    }
}