using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.State;
using SpaceTaxi_1.SpaceTaxiStates;

namespace SpaceTaxi_1.GameStates {
    public class MainMenu : IGameState {
        private static MainMenu instance;
        private int activeMenuButton;

        private Entity backGroundImage;
        private int maxMenuButtons = 3;
        private Text[] menuButtons = new Text[3];

        public void GameLoop() { }

        public void InitializeGameState() { }

        public void UpdateGameLogic() { }

        public void RenderState() {
            backGroundImage = new Entity(new DynamicShape(new Vec2F(0.0f, 0.0f), new Vec2F(1f, 1f)),
                new Image(Path.Combine("Assets", "Images", "SpaceBackground.png")));
            backGroundImage.RenderEntity();
            menuButtons[0] = new Text("New Game", new Vec2F(0.5f, 0.5f), new Vec2F(0.2f, 0.2f));
            menuButtons[2] = new Text("Quit", new Vec2F(0.5f, 0.1f), new Vec2F(0.2f, 0.2f));
            menuButtons[1] = new Text("LevelSelect", new Vec2F(0.5f, 0.3f), new Vec2F(0.2f, 0.2f));
            for (var i = 0; i < 3; i++) {
                if (i == activeMenuButton) {
                    menuButtons[i].SetColor(new Vec3F(0f, 0.99f, 0f));
                } else {
                    menuButtons[i].SetColor(new Vec3F(0.99f, 0f, 0f));
                }

                menuButtons[i].RenderText();
            }
        }

        public void HandleKeyEvent(string keyValue, string keyAction) {
            if (keyAction == "KEY_PRESS") {
                if (keyValue == "KEY_ENTER") {
                    switch (activeMenuButton) {
                    case 0:
                        SpaceTaxiBus.GetBus().RegisterEvent(
                            GameEventFactory<object>.CreateGameEventForAllProcessors(
                                GameEventType.GameStateEvent,
                                this,
                                "CHANGE_STATE",
                                "GAME_RUNNING", ""));
                        break;

                    case 2:
                        SpaceTaxiBus.GetBus().RegisterEvent(
                            GameEventFactory<object>.CreateGameEventForAllProcessors(
                                GameEventType.WindowEvent,
                                this,
                                "CLOSE_WINDOW",
                                "", ""));
                        break;

                    case 1:
                        SpaceTaxiBus.GetBus().RegisterEvent(
                            GameEventFactory<object>.CreateGameEventForAllProcessors(
                                GameEventType.GameStateEvent,
                                this,
                                "CHANGE_STATE",
                                "LEVEL_SELECT", ""));
                        break;
                    }
                } else if (keyValue == "KEY_UP") {
                    if (activeMenuButton == 0) {
                        activeMenuButton = 2;
                    } else {
                        activeMenuButton += -1;
                    }
                } else if (keyValue == "KEY_DOWN") {
                    if (activeMenuButton == 2) {
                        activeMenuButton = 0;
                    } else {
                        activeMenuButton += 1;
                    }
                }
            }
        }

        public static MainMenu GetInstance() {
            return MainMenu.instance ?? (MainMenu.instance = new MainMenu());
        }
    }
}