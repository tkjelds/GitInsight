using System;
using System.Collections.Generic;
using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.State;
using SpaceTaxi_1.Parser;
using SpaceTaxi_1.SpaceTaxiStates;

namespace SpaceTaxi_1.GameStates {
    public class LevelSelect : IGameState {
        private static LevelSelect instance;
        private static ForegroundCreator foregroundCreator = new ForegroundCreator();

        public static EntityContainer<Entity> CurrentLevel;
        public static List<Entity> CurrentLevelPlatform;
        private int activeMenuButton;
        private Entity backGroundImage;
        private int maxMenuButtons = 2;
        private Text[] menuButtons = new Text[2];
        public void GameLoop() {
            throw new NotImplementedException();
        }

        public void InitializeGameState() { }

        public void UpdateGameLogic() { }

        public void RenderState() {
            backGroundImage = new Entity(new DynamicShape(new Vec2F(0.0f, 0.0f), new Vec2F(1f, 1f)),
                new Image(Path.Combine("Assets", "Images", "SpaceBackground.png")));
            backGroundImage.RenderEntity();
            menuButtons[0] = new Text("Beach", new Vec2F(0.5f, 0.5f), new Vec2F(0.2f, 0.2f));
            menuButtons[1] = new Text("CandyLand", new Vec2F(0.5f, 0.3f), new Vec2F(0.2f, 0.2f));
            for (var i = 0; i < 2; i++) {
                if (i == activeMenuButton) {
                    menuButtons[i].SetColor(new Vec3F(0f, 0.99f, 0f));
                } else {
                    menuButtons[i].SetColor(new Vec3F(0.99f, 0f, 0f));
                }

                menuButtons[i].RenderText();
            }
        }
/// <summary>
///     Whenever a level is selected, the current platforms and foreground change to the chosen map
/// </summary>
/// <param name="keyValue"></param>
/// <param name="keyAction"></param>
        public void HandleKeyEvent(string keyValue, string keyAction) {
            if (keyAction == "KEY_PRESS") {
                if (keyValue == "KEY_ENTER") {
                    switch (activeMenuButton) {
                    case 0:
                        LevelSelect.CurrentLevel =
                            LevelSelect.foregroundCreator.EntityListCreator("the-beach.txt");
                        LevelSelect.CurrentLevelPlatform =
                            LevelSelect.foregroundCreator.PlatformListCreator("the-beach.txt");
                        SpaceTaxiBus.GetBus().RegisterEvent(
                            GameEventFactory<object>.CreateGameEventForAllProcessors(
                                GameEventType.GameStateEvent,
                                this,
                                "CHANGE_STATE",
                                "MAIN_MENU", ""));
                        break;

                    case 1:
                        LevelSelect.CurrentLevel =
                            LevelSelect.foregroundCreator.EntityListCreator("short-n-sweet.txt");
                        LevelSelect.CurrentLevelPlatform =
                            LevelSelect.foregroundCreator.PlatformListCreator("short-n-sweet.txt");
                        SpaceTaxiBus.GetBus().RegisterEvent(
                            GameEventFactory<object>.CreateGameEventForAllProcessors(
                                GameEventType.GameStateEvent,
                                this,
                                "CHANGE_STATE",
                                "MAIN_MENU", ""));
                        break;
                    }
                } else if (keyValue == "KEY_UP") {
                    activeMenuButton = activeMenuButton == 1 ? 0 : 1;
                } else if (keyValue == "KEY_DOWN") {
                    activeMenuButton = activeMenuButton == 0 ? 1 : 0;
                } else if (keyValue == "KEY_ESCAPE") {
                    SpaceTaxiBus.GetBus().RegisterEvent(GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.GameStateEvent,
                        this,
                        "CHANGE_STATE",
                        "MAIN_MENU", ""));
                }
            }
        }

        public static LevelSelect GetInstance() {
            return LevelSelect.instance ?? (LevelSelect.instance = new LevelSelect());
        }
    }
}