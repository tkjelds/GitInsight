using DIKUArcade.Math;
using DIKUArcade.Timers;

namespace SpaceTaxi_1 {
    public class Movement {
        private GameTimer _GameTimer = new GameTimer(60, 60);
        private Vec2F _Gravity = new Vec2F(0.0f, 0.09f);
    }
}