﻿namespace SpaceTaxi_1 {
    public enum Orientation {
        Left,
        Right
    }
}