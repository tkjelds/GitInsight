using System.Collections.Generic;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;

namespace SpaceTaxi_1.Parser {
    public class ForegroundCreator {
        private ASCIIReader read = new ASCIIReader();

        /// <summary>
        ///     Uses the methods developed in ASCIIReader to produce a list of entities. that can be
        ///     rendered through entity.render.
        /// </summary>
        /// <param name="LevelName">Name of the level-file</param>
        /// <returns></returns>
        public EntityContainer<Entity> EntityListCreator(string LevelName) {
            const int MapHeight = 40;
            const int MapWidth = 23;
            const double MapWidthDivided = 0.043478;
            const double MapHeightDivided = 0.025;
            EntityContainer<Entity> list = new EntityContainer<Entity>();
            var LevelTable = read.LevelToTable(LevelName);
            for (float i = 0; i < MapWidth; i++) {
                for (float j = 0; j < MapHeight; j++) {
                    var ImageKey = read.LevelToString(LevelName)[MapWidth - (int) i - 1]
                        .Substring(MapHeight - (int) j - 1, 1);
                    // ImageKey contains a string with a character that corresponds to placement 
                    // of the for loops.
                    if (LevelTable.ContainsKey(ImageKey)) {
                        var Image = (string) LevelTable[ImageKey];
                        // Image contains the file name, found trough the hashtable. 
                        list.AddDynamicEntity(new Entity(new DynamicShape(
                                new Vec2F((float) (MapHeightDivided * j),
                                    (float) (MapWidthDivided * i)),
                                new Vec2F((float) MapHeightDivided, (float) MapWidthDivided)),
                            new Image(read.GetImageFilePath(Image))));
                    }
                }
            }

            return list;
        }

        public List<Entity> PlatformListCreator(string LevelName) {
            const int MapHeight = 40;
            const int MapWidth = 23;
            const double MapWidthDivided = 0.043478;
            const double MapHeightDivided = 0.025;
            var list = new List<Entity>();
            var PlatformTable = read.PlatformToTable(LevelName);
            for (float i = 0; i < MapWidth; i++) {
                for (float j = 0; j < MapHeight; j++) {
                    var ImageKey = read.LevelToString(LevelName)[MapWidth - (int) i - 1]
                        .Substring(MapHeight - (int) j - 1, 1);
                    if (PlatformTable.ContainsKey(ImageKey)) {
                        var Image = (string) PlatformTable[ImageKey];
                        list.Add(new Entity(new DynamicShape(
                                new Vec2F((float) (MapHeightDivided * j),
                                    (float) (MapWidthDivided * i)),
                                new Vec2F((float) MapHeightDivided, (float) MapWidthDivided)),
                            new Image(read.GetImageFilePath(Image))));
                    }
                }
            }

            return list;
        }
    }
}