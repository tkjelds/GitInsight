using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace SpaceTaxi_1.Parser {
    public class ASCIIReader {
        /// <summary>
        ///     Makes a list of string containing the map of the ASCII file.
        ///     As such the first element is the first row of the tablemap
        ///     and the last element is the last row of the tablemap
        /// </summary>
        /// <param name="LevelName">Filename of the Level</param>
        /// <returns></returns>
        public List<string> LevelToString(string LevelName) {
            var stringlist = new List<string>();
            for (var i = 0; i < 23; i++) {
                var line = File.ReadLines(GetLevelFilePath(LevelName)).Skip(i).Take(1).First();
                line = ASCIIReader.Reverse(line);
                stringlist.Add(line);
            }

            return stringlist;
        }

        /// <summary>
        ///     Returns a hashtable of the level images. The key corresponds to the
        ///     index (ie. % or g or H) and the value corresponds to the
        ///     image.
        /// </summary>
        /// <param name="LevelName">Filename of the Level</param>
        /// <returns></returns>
        public Hashtable LevelToTable(string LevelName) {
            var Length = UntilCustomer(LevelName);
            var leveltable = new Hashtable();
            for (var i = 27; i < Length; i++) {
                var temp = File.ReadLines(GetLevelFilePath(LevelName)).Skip(i).Take(1).First();
                if (temp.Contains(")")) {
                    var templength = temp.Length - 1;
                    leveltable.Add(temp.Substring(0, 1),
                        temp.Substring(3, templength - 2));
                    // Adds the first letter as the key and the remaining as the value 
                }
            }

            return leveltable;
        }
        /// <summary>
        /// Returns a list with all the platform elements
        /// </summary>
        /// <param name="LevelName"> The name of the level, including .txt</param>
        /// <returns> a list the all the platform elements</returns>
        private List<string> PlatformList(string LevelName) {
            var _PlatformList = new List<string>();
            var _PlatformLine = File.ReadLines(GetLevelFilePath(LevelName)).Skip(25).First();
            var _PlatformLineLength = _PlatformLine.Length;
            for (var i = 11; i < _PlatformLineLength; i++) {
                _PlatformList.Add(_PlatformLine.Substring(i, 1));
                //Adds all the elements following "platform"
            }
            _PlatformList.RemoveAll(item => item == " ");
            _PlatformList.RemoveAll(item => item == ",");
            //Removes all spaces and commas in the list. so we only have the platform elements
            return _PlatformList;
        }
        /// <summary>
        /// Returns a hashtable with the platform elements and their imagefile name
        /// </summary>
        /// <param name="LevelName"> The level name including .txt</param>
        /// <returns> A list with the platform hashtable</returns>
        public Hashtable PlatformToTable(string LevelName) {
            var Length = UntilCustomer(LevelName);
            var _PlatformTable = new Hashtable();
            var _PlatformList = PlatformList(LevelName);
            for (var i = 0; i < _PlatformList.Count; i++) {
                // Goes through all the elements in the platformlist
                for (var j = 27; j < Length; j++) {
                    //Goes through all the image lines the doc
                    var _LevelLine = File.ReadLines(GetLevelFilePath(LevelName)).Skip(j).Take(1)
                        .First();
                    if (_LevelLine.Contains(")")) {
                        if (_LevelLine.Substring(0, 1) == _PlatformList[i]) {
                            // Checks if the first index is equal to the element in the list
                            var templength = _LevelLine.Length - 1;
                            _PlatformTable.Add(_LevelLine.Substring(0, 1),
                                _LevelLine.Substring(3, templength - 2));
                            // Adds the platform element and corresponding image name to the hashtable
                        }
                    }
                }
            }
            return _PlatformTable;
        }

        /// <summary>
        ///     Finds when the first customer appears in the in the file.
        /// </summary>
        /// <param name="LevelName">Filename of the Level</param>
        /// <returns></returns>
        private int UntilCustomer(string LevelName) {
            for (var i = 1; i < NumberOfLines(LevelName); i++) {
                var line = File.ReadLines(GetLevelFilePath(LevelName)).Skip(i).Take(1).First();
                if (line.Contains("Customer")) {
                    return i;
                }
            }

            return NumberOfLines(LevelName);
        }

        /// <summary>
        ///     Finds the length of the entire file.
        /// </summary>
        /// <param name="LevelName">Filename of the Level</param>
        /// <returns></returns>
        private int NumberOfLines(string LevelName) {
            var counter = 1;
            string line;
            var file = new StreamReader(GetLevelFilePath(LevelName));
            while ((line = file.ReadLine()) != null) {
                counter++;
            }

            return counter;
        }

        /// <summary>
        ///     Reverses a string.
        /// </summary>
        /// <param name="s">The string we wished to reverse</param>
        /// <returns></returns>
        private static string Reverse(string s) {
            var charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }

        // The method above, was taken from a previous exercise 
        /// <summary>
        ///     Finds full directory path of the given level.
        /// </summary>
        /// <remarks>This code is borrowed from Texture.cs in DIKUArcade.</remarks>
        /// <param name="filename">Filename of the level.</param>
        /// <returns>Directory path of the level.</returns>
        /// <exception cref="FileNotFoundException">File does not exist.</exception>
        public string GetLevelFilePath(string filename) {
            // Find base path.
            var dir = new DirectoryInfo(Path.GetDirectoryName(
                Assembly.GetExecutingAssembly().Location));

            while (dir.Name != "bin") {
                dir = dir.Parent;
            }

            dir = dir.Parent;

            // Find level file.
            var path = Path.Combine(dir.FullName, "Levels", filename);

            if (!File.Exists(path)) {
                throw new FileNotFoundException($"Error: The file \"{path}\" does not exist.");
            }

            return path;
        }

        // The method above, was taken from a previous exercise 
        /// <summary>
        ///     Finds full directory path of the given image.
        /// </summary>
        /// <remarks>This code is borrowed from Texture.cs in DIKUArcade.</remarks>
        /// <param name="filename">Filename of the image.</param>
        /// <returns>Directory path of the image.</returns>
        /// <exception cref="FileNotFoundException">File does not exist.</exception>
        public string GetImageFilePath(string filename) {
            // Find base path.
            var dir = new DirectoryInfo(Path.GetDirectoryName(
                Assembly.GetExecutingAssembly().Location));

            while (dir.Name != "bin") {
                dir = dir.Parent;
            }

            dir = dir.Parent;

            // Find level file.
            var path = Path.Combine(dir.FullName, "Assets", "Images", filename);

            if (!File.Exists(path)) {
                throw new FileNotFoundException($"Error: The file \"{path}\" does not exist.");
            }

            return path;
        }
    }
}