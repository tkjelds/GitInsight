namespace SpaceTaxi_1.SpaceTaxiStates {
    public class DeclaredGameStates {
        public enum GameStateType {
            GameRunning,
            GamePaused,
            MainMenu,
            LevelSelect,
            GameOver
        }
    }
}