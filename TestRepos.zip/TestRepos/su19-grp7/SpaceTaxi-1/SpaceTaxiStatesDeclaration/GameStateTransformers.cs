using System;

namespace SpaceTaxi_1.SpaceTaxiStates {
    public class GameStateTransformers {
        public DeclaredGameStates.GameStateType TransformStringToState(string state) {
            switch (state) {
            case "GAME_RUNNING":
                return DeclaredGameStates.GameStateType.GameRunning;
            case "GAME_PAUSED":
                return DeclaredGameStates.GameStateType.GamePaused;
            case "MAIN_MENU":
                return DeclaredGameStates.GameStateType.MainMenu;
            case "LEVEL_SELECT":
                return DeclaredGameStates.GameStateType.LevelSelect;
            case "GAME_OVER":
                return DeclaredGameStates.GameStateType.GameOver;
            default:
                throw new SystemException("The given string is valid with any gamestate");
            }
        }

        public string TransformStateTosString(DeclaredGameStates.GameStateType state) {
            switch (state) {
            case DeclaredGameStates.GameStateType.GameRunning:
                return "GAME_RUNNING";
            case DeclaredGameStates.GameStateType.GamePaused:
                return "GAME_PAUSED";
            case DeclaredGameStates.GameStateType.MainMenu:
                return "MAIN_MENU";
            case DeclaredGameStates.GameStateType.LevelSelect:
                return "LEVEL_SELECT";
            case DeclaredGameStates.GameStateType.GameOver:
                return "GAME_OVER";
            default:
                throw new SystemException(
                    "The given gamestate did not correpond with any of the indexed strings");
            }
        }
    }
}