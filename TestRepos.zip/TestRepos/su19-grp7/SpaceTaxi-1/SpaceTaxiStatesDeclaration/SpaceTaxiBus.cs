using DIKUArcade.EventBus;

namespace SpaceTaxi_1.SpaceTaxiStates {
    public class SpaceTaxiBus {
        public static GameEventBus<object> EventBus;

        public static GameEventBus<object> GetBus() {
            return SpaceTaxiBus.EventBus ?? (SpaceTaxiBus.EventBus = new GameEventBus<object>());
        }
    }
}