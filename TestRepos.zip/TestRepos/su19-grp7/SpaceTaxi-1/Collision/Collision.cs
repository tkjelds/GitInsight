using System;
using System.Collections.Generic;
using DIKUArcade;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Physics;
using SpaceTaxi_1.SpaceTaxiStates;

namespace SpaceTaxi_1.Collision {
    public class Collision {
        public void ObjectCollision(Player Player, EntityContainer<Entity> Foreground) {
            if (Foreground != null && Player != null ) {
            foreach (Entity entity in Foreground) {
                var ColData = CollisionDetection.Aabb(Player.Entity.Shape.AsDynamicShape(), entity.Shape);
                    if (ColData.Collision) {
                        SpaceTaxiBus.GetBus().RegisterEvent(
                            GameEventFactory<object>.CreateGameEventForAllProcessors(
                                GameEventType.GameStateEvent, this, "CHANGE_STATE", "GAME_OVER", ""));
                    }
                }

            }

        }
    }
}