﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using NUnit.Framework;
using SpaceTaxi_1.Parser;

namespace SpaceTaxiTest {
    [TestFixture]
    public class Tests {
        [Test]
        
        
        public void TestLevelRead() {
            string LevelName = "TestLevel.txt";
            var stringlist = new List<string>();
            
                // If levels ever exceed a height of 23 units, the test will not
                // successfully load all of the level
               for (var i = 0; i < 23; i++) {
                    var line = File.ReadLines(@"..\..\Levels\" + LevelName).Skip(i).Take(1).First();
                         stringlist.Add(line);
                         }
            
                         Assert.AreEqual("this is the first line of the text document", stringlist[0]);
                         Assert.AreEqual("fez", stringlist[22]);
                         
        }
        
        [Test]
        public void TestLevelStringToHashtable() {
            string LevelName = "TestLevel.txt";
                var counter = 1;
                var leveltable = new Hashtable();
            
                // If list of Hashkeys is on other lines than between 27 & 42
                // the test is failed
                for (var i = 27; i < 43; i++) {
                    var temp = File.ReadLines(@"..\..\Levels\" + LevelName).Skip(i).Take(1).First();
                    if (temp.Contains(")")) {
                        var templength = temp.Length - 1;
                        leveltable.Add(temp.Substring(0, 1), temp.Substring(3, templength - 2));
                    }
                }

                Assert.AreEqual("testy", leveltable[1]);
                Assert.IsNull(leveltable[9]);
            }
        
        [Test]
        public void TestLevelStringWithHashtableCheck() {  
        
            ASCIIReader read = new ASCIIReader();
        
            string LevelName = "TestLevel.txt";
            var list = new List<Entity>();    
            var LevelTable = read.leveltotable(LevelName);

            for (float i = 0; i < 23; i++) {
                for (float j = 0; j < 40; j++) {
                    var TempS = read.LevelToString(LevelName)[23-(int) i - 1]
                        .Substring(40-(int) j - 1, 1);

                    if (TempS != " " && TempS != "^" && TempS != ">") {
                        var TempC = (string) LevelTable[TempS];
                        list.Add(new Entity(new DynamicShape(
                                new Vec2F(0.025f * j, 0.0434f * i),
                                new Vec2F(0.025f, 0.0434f)),
                            new Image(@"Assets\Images\" + TempC)));
                        
                        Assert.IsNull(list[(int) j]);
                    }
                }
                
                

            

            }

          
        }
            
        }
}

    
