﻿namespace Galaga_Exercise_1 {
    internal class Program {
        public static void Main(string[] args) {
            var galaga = new Game();
            galaga.AddEnemies();
            galaga.GameLoop();
        }
    }
}