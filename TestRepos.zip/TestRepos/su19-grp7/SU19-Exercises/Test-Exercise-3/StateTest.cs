﻿using Galaga_Exercise_3.GalagaStates;
using NUnit.Framework;

namespace Test_Exercise_3 {
    [TestFixture]
    public class Tests {
        [Test]
        public void TransformGameStateToStringMenu() {
            var StateTests = new StateTransformer();
            Assert.AreEqual("MAIN_MENU", StateTests.TransformStateToString(GameStateType.MainMenu));
        }

        [Test]
        public void TransformGameStateToStringPaused() {
            var StateTests = new StateTransformer();
            Assert.AreEqual("GAME_PAUSED",
                StateTests.TransformStateToString(GameStateType.GamePaused));
        }

        [Test]
        public void TransformGameStateToStringRunnning() {
            var StateTests = new StateTransformer();
            Assert.AreEqual("GAME_RUNNING",
                StateTests.TransformStateToString(GameStateType.GameRunning));
        }

        [Test]
        public void TransformStringToGamestateMenu() {
            var StateTests = new StateTransformer();
            Assert.AreEqual(GameStateType.MainMenu, StateTests.TransformStringToState("MAIN_MENU"));
        }

        [Test]
        public void TransformStringToGamestatePaused() {
            var StateTests = new StateTransformer();
            Assert.AreEqual(GameStateType.GamePaused,
                StateTests.TransformStringToState("GAME_PAUSED"));
        }

        [Test]
        public void TransformStringToGamestateRunning() {
            var StateTests = new StateTransformer();
            Assert.AreEqual(GameStateType.GameRunning,
                StateTests.TransformStringToState("GAME_RUNNING"));
        }
    }
}