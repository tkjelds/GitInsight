using DIKUArcade.Entities;
using Galaga_Exercise_2.GalagaEntities;
using Galaga_Exercise_2.MovementStrategy;

namespace Galaga_Exercise_2 {
    public class Down : IMovementStrategy {
        public void MoveEnemy(Enemy enemy) {
            enemy.Shape.Position.Y -= 0.0003f;
        }

        public void MoveEnemies(EntityContainer<Enemy> enemies) {
            foreach (Enemy enemy in enemies) {
                MoveEnemy(enemy);
            }
        }
    }
}