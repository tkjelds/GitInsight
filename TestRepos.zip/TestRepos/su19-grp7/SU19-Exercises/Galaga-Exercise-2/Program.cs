﻿namespace Galaga_Exercise_2 {
    internal class Program {
        public static void Main(string[] args) {
            var galaga = new Game();
            galaga.GameLoop();
        }
    }
}