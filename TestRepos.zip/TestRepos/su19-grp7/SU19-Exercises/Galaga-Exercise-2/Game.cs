using System;
using System.Collections.Generic;
using System.IO;
using DIKUArcade;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.Physics;
using DIKUArcade.Timers;
using Galaga_Exercise_2.GalagaEntities;
using Galaga_Exercise_2.Squadrons;

namespace Galaga_Exercise_2 {
    public class Game : IGameEventProcessor<object> {
        private Down down;
        private EntityContainer<Enemy> enemies;
        private List<Image> enemyStrides;
        private GameEventBus<object> eventBus;
        private int explosionLength = 500;
        private AnimationContainer explosions;

        private List<Image> explosionStrides;
        private GameTimer gameTimer;
        private NoMove noMove;
        private Player player;
        private Score score;
        private SquadronFormation1 sqd1;
        private SquadronFormation2 sqd2;
        private SquadronFormation3 sqd3;
        private Window win;
        private ZigZagDown zigZagDown;

        public Game() {
            // For the window, we recommend a 500x500 resolution (a 1:1 aspect ratio).
            win = new Window("Galaga", 500, 500);
            gameTimer = new GameTimer(60, 60);
            player = new Player(this,
                new DynamicShape(new Vec2F(0.45f, 0.1f), new Vec2F(0.1f, 0.1f)),
                new Image(Path.Combine("Assets", "Images", "Player.png")));
            eventBus = new GameEventBus<object>();
            eventBus.InitializeEventBus(new List<GameEventType> {
                GameEventType.InputEvent, // key press / key release
                GameEventType.WindowEvent, // messages to the window
                GameEventType.PlayerEvent // player movement
            });
            win.RegisterEventBus(eventBus);
            eventBus.Subscribe(GameEventType.InputEvent, this);
            eventBus.Subscribe(GameEventType.WindowEvent, this);
            eventBus.Subscribe(GameEventType.PlayerEvent, player);

            // Look at the file and consider why we place the number '4' here.
            // Note: The number 4 is used due to the amount of frames of animation the enemies have.
            enemyStrides = ImageStride.CreateStrides(4,
                Path.Combine("Assets", "Images", "BlueMonster.png"));
            sqd1 = new SquadronFormation1();
            sqd2 = new SquadronFormation2();
            sqd3 = new SquadronFormation3();
            zigZagDown = new ZigZagDown();
            down = new Down();
            noMove = new NoMove();
            enemies = sqd1.Enemies;

            playerShots = new List<PlayerShot>();
            sqd1.CreateEnemies(enemyStrides);
            sqd2.CreateEnemies(enemyStrides);
            sqd3.CreateEnemies(enemyStrides);


            explosionStrides = ImageStride.CreateStrides(8,
                Path.Combine("Assets", "Images", "Explosion.png"));
            explosions = new AnimationContainer(8000);

            score = new Score(new Vec2F(0.05f, 0.01f), new Vec2F(0.2f, 0.2f));
        }

        public List<PlayerShot> playerShots { get; }

        public void ProcessEvent(GameEventType eventType,
            GameEvent<object> gameEvent) {
            if (eventType == GameEventType.WindowEvent) {
                switch (gameEvent.Message) {
                case "CLOSE_WINDOW":
                    win.CloseWindow();
                    break;
                }
            } else if (eventType == GameEventType.InputEvent) {
                switch (gameEvent.Parameter1) {
                case "KEY_PRESS":
                    KeyPress(gameEvent.Message);
                    break;
                case "KEY_RELEASE":
                    KeyRelease(gameEvent.Message);
                    break;
                }
            }
        }

        public void GameLoop() {
            while (win.IsRunning()) {
                gameTimer.MeasureTime();

                while (gameTimer.ShouldUpdate()) {
                    win.PollEvents();
                    eventBus.ProcessEvents();
                    player.Move();

                    if (enemies.CountEntities() == 0) {
                        var ran = new Random();

                        switch (ran.Next(2, 3)) {
                        case 1:
                            enemies = sqd1.Enemies;
                            break;

                        case 2:
                            enemies = sqd2.Enemies;
                            break;

                        case 3:
                            enemies = sqd3.Enemies;
                            break;
                        }
                    }

                    zigZagDown.MoveEnemies(enemies);
                    // Update game logic here
                }

                if (gameTimer.ShouldRender()) {
                    IterateShots();
                    win.Clear();
                    player.Entity.RenderEntity();
                    enemies.RenderEntities();

                    foreach (var playerShot in playerShots) {
                        playerShot.RenderEntity();
                    }

                    score.RenderScore();
                    explosions.RenderAnimations();
                    // Render gameplay entities here
                    win.SwapBuffers();
                }

                if (gameTimer.ShouldReset()) {
                    // 1 second has passed - display last captured ups and fps
                    win.Title = "Galaga | UPS: " + gameTimer.CapturedUpdates +
                                ", FPS: " + gameTimer.CapturedFrames;
                }
            }
        }

        private void KeyPress(string key) {
            switch (key) {
            case "KEY_ESCAPE":
                eventBus.RegisterEvent(
                    GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.WindowEvent, this, "CLOSE_WINDOW", "", ""));
                break;
            case "KEY_D":
                eventBus.RegisterEvent(
                    GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.PlayerEvent, this, "RIGHT", "", ""));
                break;
            case "KEY_A":
                eventBus.RegisterEvent(
                    GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.PlayerEvent, this, "LEFT", "", ""));
                break;
            case "KEY_SPACE":
                player.Addshot();
                break;
            }
        }

        public void IterateShots() {
            foreach (var shot in playerShots) {
                shot.Shape.Move();
                if (shot.Shape.Position.Y > 1.0f) {
                    shot.DeleteEntity();
                }

                foreach (Enemy enemy in enemies) {
                    var coldata = CollisionDetection.Aabb(shot.Shape.AsDynamicShape(), enemy.Shape);
                    if (!coldata.Collision) {
                        continue;
                    }

                    shot.DeleteEntity();
                    enemy.DeleteEntity();
                    score.AddPoint();
                    score.RenderScore();
                    AddExplosion(enemy.Shape.Position.X, enemy.Shape.Position.Y
                        , enemy.Shape.Extent.X, enemy.Shape.Extent.Y);
                }

                var newEnemies = new EntityContainer<Enemy>();
                foreach (Enemy enemy in enemies) {
                    if (!enemy.IsDeleted()) {
                        newEnemies.AddDynamicEntity(enemy);
                    }
                }

                enemies = newEnemies;
                var newPlayerShots = new List<PlayerShot>();
                foreach (var playerShot in playerShots) {
                    if (!playerShot.IsDeleted()) {
                        newPlayerShots.Add(shot);
                    }
                }
            }
        }

        public void KeyRelease(string key) {
            switch (key) {
            case "KEY_D":
                eventBus.RegisterEvent(
                    GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.PlayerEvent, this, "BRAKE", "", ""));
                break;
            case "KEY_A":
                eventBus.RegisterEvent(
                    GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.PlayerEvent, this, "BRAKE", "", ""));
                break;
            }
        }

        public void AddExplosion(float posX, float posY,
            float extentX, float extentY) {
            explosions.AddAnimation(
                new StationaryShape(posX, posY, extentX, extentY), explosionLength,
                new ImageStride(explosionLength / 8, explosionStrides));
        }
    }
}