using System;
using DIKUArcade.Entities;
using DIKUArcade.Math;
using Galaga_Exercise_2.GalagaEntities;
using Galaga_Exercise_2.MovementStrategy;

namespace Galaga_Exercise_2 {
    public class ZigZagDown : IMovementStrategy {
        public void MoveEnemy(Enemy enemy) {
            enemy.Shape.Position = new Vec2F(
                (float) (enemy.startPos.X +
                         0.05f *
                         Math.Sin(2f * Math.PI *
                                  (enemy.startPos.Y - (enemy.Shape.Position.Y - 0.0003f)) /
                                  0.045f))
                , enemy.Shape.Position.Y - 0.0003f);
        }

        public void MoveEnemies(EntityContainer<Enemy> enemies) {
            foreach (Enemy enemy in enemies) {
                MoveEnemy(enemy);
            }
        }
    }
}