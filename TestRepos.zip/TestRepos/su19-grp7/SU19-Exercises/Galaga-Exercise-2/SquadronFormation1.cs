using System.Collections.Generic;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using Galaga_Exercise_2.GalagaEntities;

namespace Galaga_Exercise_2 {
    namespace Squadrons {
        public class SquadronFormation1 : ISquadron {
            public EntityContainer<Enemy> Enemies { get; } = new EntityContainer<Enemy>();
            public int MaxEnemies { get; }

            public void CreateEnemies(List<Image> enemyStrides) {
                for (var i = 1; i < 9; i++) {
                    Enemies.AddDynamicEntity(new Enemy(
                        new DynamicShape(new Vec2F(i * 0.1f, 0.9f),
                            new Vec2F(0.1f, 0.1f)),
                        new ImageStride(80, enemyStrides), new Vec2F(i * 0.1f, 0.9f)));

                    Enemies.AddDynamicEntity(new Enemy(
                        new DynamicShape(new Vec2F(i * 0.1f, 0.8f),
                            new Vec2F(0.1f, 0.1f)),
                        new ImageStride(80, enemyStrides), new Vec2F(i * 0.1f, 0.8f)));

                    Enemies.AddDynamicEntity(new Enemy(
                        new DynamicShape(new Vec2F(i * 0.1f, 0.7f),
                            new Vec2F(0.1f, 0.1f)),
                        new ImageStride(80, enemyStrides), new Vec2F(i * 0.1f, 0.7f)));

                    Enemies.AddDynamicEntity(new Enemy(
                        new DynamicShape(new Vec2F(i * 0.1f, 0.6f),
                            new Vec2F(0.1f, 0.1f)),
                        new ImageStride(80, enemyStrides), new Vec2F(i * 0.1f, 0.7f)));
                }
            }
        }
    }
}