using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;

namespace Galaga_Exercise_1 {
    public class Player : Entity {
        private Game game;

        public Player(Game game, DynamicShape shape, IBaseImage image)
            : base(shape, image) {
            this.game = game;
        }

        public void Direction(Vec2F vec) {
            Shape.AsDynamicShape().ChangeDirection(vec);
        }

        public void Move() {
            if (Shape.Position.X > 0.0000000000001f && Shape.Position.X < 0.901000000000000f) {
                Shape.Move();
            }

            if (Shape.Position.X <= 0.0f) {
                Shape.Position.X = 0.0000000001f;
            }

            if (Shape.Position.X > 0.9000000000000000001f) {
                Shape.Position.X = 0.9f;
            }
        }

        public void Addshot() {
            var shot = new PlayerShot(game, new DynamicShape
                (new Vec2F(Shape.Position.X + 0.045f, Shape.Position.Y + 0.1f),
                    new Vec2F(0.008f, 0.027f)),
                new Image(Path.Combine("Assets", "Images", "BulletRed2.PNG")));
            game.playerShots.Add(shot);
        }
    }
}