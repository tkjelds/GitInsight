using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Graphics;
using DIKUArcade.Math;

namespace Galaga_Exercise_3 {
    public class Player : IGameEventProcessor<object> {
        public Player(DynamicShape shape, IBaseImage image) {
            Entity = new Entity(shape, image);
        }

        public Entity Entity { get; }

        public void ProcessEvent(GameEventType eventType, GameEvent<object> gameEvent) {
            if (eventType == GameEventType.PlayerEvent) {
                switch (gameEvent.Message) {
                case "LEFT":
                    Direction(new Vec2F(-0.01f, 0.0f));
                    break;

                case "RIGHT":
                    Direction(new Vec2F(0.01f, 0.0f));
                    break;

                case "BRAKE":
                    Direction(new Vec2F(0.0f, 0.0f));
                    break;
                }
            }
        }

        private void Direction(Vec2F vec) {
            Entity.Shape.AsDynamicShape().ChangeDirection(vec);
        }

        public void Move() {
            if (Entity.Shape.Position.X > 0.0000000000001f &&
                Entity.Shape.Position.X < 0.901000000000000f) {
                Entity.Shape.Move();
            }

            if (Entity.Shape.Position.X <= 0.0f) {
                Entity.Shape.Position.X = 0.0000000001f;
            }

            if (Entity.Shape.Position.X > 0.9000000000000000001f) {
                Entity.Shape.Position.X = 0.9f;
            }
        }

        public void Addshot() {
            var shot = new PlayerShot(new DynamicShape
                (new Vec2F(Entity.Shape.Position.X + 0.045f, Entity.Shape.Position.Y + 0.1f),
                    new Vec2F(0.008f, 0.027f)),
                new Image(Path.Combine("Assets", "Images", "BulletRed2.PNG")));
            GameRunning.playerShots.Add(shot);
        }
    }
}