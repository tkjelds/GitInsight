using System;
using System.ComponentModel;
using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.State;
using OpenTK.Graphics.ES20;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using GL = OpenTK.Graphics.ES20.GL;

namespace Galaga_Exercise_3 {
    public class MainMenu : IGameState {
        private static MainMenu instance;
        private int activeMenuButton = 0;

        private Entity backGroundImage;
        private int maxMenuButtons = 2;
        private Text[] menuButtons = new Text[2];
        


        public void GameLoop() {
            
        }

        public void InitializeGameState() {
        }

        public void UpdateGameLogic() {
        
        }

        public void RenderState() {
            backGroundImage = new Entity(new DynamicShape(new Vec2F(0.0f,0.0f),new Vec2F(1f,1f) ), new Image(Path.Combine("Assets", "Images", "SpaceBackground.png") ));
            backGroundImage.RenderEntity();
            menuButtons[0] = new Text("New Game", new Vec2F(0.5f, 0.5f), new Vec2F(0.2f, 0.2f));
            menuButtons[1] = new Text("Quit", new Vec2F(0.5f, 0.3f), new Vec2F(0.2f, 0.2f));
            for (int i = 0; i < 2; i++) {
                if (i == activeMenuButton) {
                    menuButtons[i].SetColor(new Vec3F(0f, 0.99f, 0f));
                } else {
                    menuButtons[i].SetColor(new Vec3F(0.99f, 0f, 0f));
                }
                menuButtons[i].RenderText();
            }
            

        }

        public void HandleKeyEvent(string keyValue, string keyAction) {
            if (keyAction == "KEY_PRESS") {
                if (keyValue == "KEY_ENTER") {
                    switch (activeMenuButton) {
                    case 0:
                        GalagaBus.GetBus().RegisterEvent( GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.GameStateEvent,
                            this,
                            "CHANGE_STATE",
                            "GAME_RUNNING", ""));
                        break;

                    case 1:
                        GalagaBus.GetBus().RegisterEvent(GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.WindowEvent,
                            this,
                            "CLOSE_WINDOW",
                            "", ""));
                        break;
                    }
                } else if (keyValue == "KEY_UP") {
                    activeMenuButton = activeMenuButton == 1 ? 0 : 1;
                } else if (keyValue == "KEY_DOWN") {
                    activeMenuButton = activeMenuButton == 0 ? 1 : 0;
                }
            }
        }

        public static MainMenu GetInstance() {
            return MainMenu.instance ?? (MainMenu.instance = new MainMenu());
        }
    }
}