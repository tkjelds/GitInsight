using System.Collections.Generic;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using Galaga_Exercise_3.GalagaEntities;

namespace Galaga_Exercise_3 {
    namespace Squadrons {
        public class SquadronFormation2 : ISquadron {
            public EntityContainer<Enemy> Enemies { get; } = new EntityContainer<Enemy>();
            public int MaxEnemies { get; }

            public void CreateEnemies(List<Image> enemyStrides) {
                for (var i = 1f; i < 6f; i++) {
                    Enemies.AddDynamicEntity(new Enemy(
                        new DynamicShape(new Vec2F(i * 0.1f + 0.1f, 0.9f),
                            new Vec2F(0.1f, 0.1f)),
                        new ImageStride(80, enemyStrides), new Vec2F(i * 0.1f + 0.1f, 0.9f)));

                    Enemies.AddDynamicEntity(new Enemy(
                        new DynamicShape(new Vec2F(i * 0.18f, 0.8f),
                            new Vec2F(0.1f, 0.1f)),
                        new ImageStride(80, enemyStrides), new Vec2F(i * 0.18f, 0.8f)));

                    Enemies.AddDynamicEntity(new Enemy(
                        new DynamicShape(new Vec2F(i * 0.22f - 0.15f, 0.6f),
                            new Vec2F(0.1f, 0.1f)),
                        new ImageStride(80, enemyStrides), new Vec2F(i * 0.22f - 0.15f, 0.6f)));

                    Enemies.AddDynamicEntity(new Enemy(
                        new DynamicShape(new Vec2F(i * 0.15f, 0.4f),
                            new Vec2F(0.1f, 0.1f)),
                        new ImageStride(80, enemyStrides), new Vec2F(i * 0.15f, 0.4f)));
                }
            }
        }
    }
}