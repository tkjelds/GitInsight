using System;
using System.Collections.Generic;
using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.EventBus;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.Physics;
using DIKUArcade.State;
using Galaga_Exercise_3.GalagaEntities;
using Galaga_Exercise_3.Squadrons;

namespace Galaga_Exercise_3 {
    public class GameRunning : IGameState {
        private static GameRunning instance;
        private Down down;

        // Members needed to be moved from Game.cs to GameRunning.cs
        // 
        // Player, Squadrons, Iterate shots, Movement strategies, explosions, score, enemies,
        //
        private EntityContainer<Enemy> enemies;
        private List<Image> enemyStrides;
        private int explosionLength = 500;
        private AnimationContainer explosions;
        private List<Image> explosionStrides;
        private NoMove noMove;
        private Player player;
        private Score score;
        private SquadronFormation1 sqd1;
        private SquadronFormation2 sqd2;
        private SquadronFormation3 sqd3;
        private ZigZagDown zigZagDown;
        public static List<PlayerShot> playerShots { get; set; }


        public void GameLoop() {
            throw new NotImplementedException();
        }

        public GameRunning() {
            InitializeGameState();
        }
        
        public void InitializeGameState() {
            player = new Player(
                new DynamicShape(new Vec2F(0.45f, 0.1f), new Vec2F(0.1f, 0.1f)),
                new Image(Path.Combine("Assets", "Images", "Player.png")));
            GalagaBus.GetBus().Subscribe(GameEventType.PlayerEvent, player);
            GalagaBus.GetBus().Subscribe(GameEventType.InputEvent, player);
            enemyStrides = ImageStride.CreateStrides(4,
                Path.Combine("Assets", "Images", "BlueMonster.png"));
            sqd1 = new SquadronFormation1();
            sqd2 = new SquadronFormation2();
            sqd3 = new SquadronFormation3();
            zigZagDown = new ZigZagDown();
            down = new Down();
            noMove = new NoMove();
            enemies = sqd1.Enemies;
            playerShots = new List<PlayerShot>();
            sqd1.CreateEnemies(enemyStrides);
            sqd2.CreateEnemies(enemyStrides);
            sqd3.CreateEnemies(enemyStrides);
            explosionStrides = ImageStride.CreateStrides(8,
                Path.Combine("Assets", "Images", "Explosion.png"));
            explosions = new AnimationContainer(8000);
            score = new Score(new Vec2F(0.05f, 0.01f), new Vec2F(0.2f, 0.2f));
        }

        public void UpdateGameLogic() {
            
            player.Move();

            if (enemies.CountEntities() == 0) {
                var ran = new Random();

                switch (ran.Next(2, 3)) {
                case 1:
                    enemies = sqd1.Enemies;
                    break;

                case 2:
                    enemies = sqd2.Enemies;
                    break;

                case 3:
                    enemies = sqd3.Enemies;
                    break;
                }
            }

            zigZagDown.MoveEnemies(enemies);
        }

        public void RenderState() {
            
            IterateShots();
            player.Entity.RenderEntity();
            enemies.RenderEntities();
            
            foreach (var playerShot in playerShots) {
                playerShot.RenderEntity();
            }

            score.RenderScore();
            explosions.RenderAnimations();
        }

        public void HandleKeyEvent(string keyValue, string keyAction) {
            if (keyAction == "KEY_PRESS") {
                switch (keyValue) {
                case "KEY_ESCAPE":
                    GalagaBus.GetBus().RegisterEvent(GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.GameStateEvent, this, "CHANGE_STATE", "GAME_PAUSED", ""));
                    break;
                case "KEY_D":
                    GalagaBus.GetBus().RegisterEvent(GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.PlayerEvent, this, "RIGHT", "", ""));
                    break;
                case "KEY_A":
                    GalagaBus.GetBus().RegisterEvent(GameEventFactory<object>.CreateGameEventForAllProcessors(
                        GameEventType.PlayerEvent, this, "LEFT", "", ""));
                    break;
                case "KEY_SPACE":
                    player.Addshot();
                    break;
                
                }
            } else if (keyAction == "KEY_RELEASE") {
                switch (keyValue) {
                    case "KEY_D":
                        GalagaBus.GetBus().RegisterEvent(GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.PlayerEvent, this, "BRAKE", "", ""));
                        break;
                    case "KEY_A":
                        GalagaBus.GetBus().RegisterEvent(GameEventFactory<object>.CreateGameEventForAllProcessors(
                            GameEventType.PlayerEvent, this, "BRAKE", "", ""));
                        break;
                }
            }
        }

        public void IterateShots() {
            foreach (var shot in playerShots) {
                shot.Shape.Move();

                if (shot.Shape.Position.Y > 1.0f) {
                    shot.DeleteEntity();
                    
                }

                foreach (Enemy enemy in enemies) {
                    var coldata = CollisionDetection.Aabb(shot.Shape.AsDynamicShape(), enemy.Shape);
                    if (!coldata.Collision) {
                        continue;
                    }

                    shot.DeleteEntity();
                    enemy.DeleteEntity();
                    score.AddPoint();
                    score.RenderScore();
                    AddExplosion(enemy.Shape.Position.X, enemy.Shape.Position.Y
                        , enemy.Shape.Extent.X, enemy.Shape.Extent.Y);
                    
                    var newEnemies = new EntityContainer<Enemy>();
                    foreach (Enemy enemy1 in enemies) {
                        if (!enemy1.IsDeleted()) {
                            newEnemies.AddDynamicEntity(enemy1);
                            
                        }
                        
                    }
                    enemies = newEnemies;
                    var newPlayerShots = new List<PlayerShot>();
                    foreach (var playerShot in playerShots) {
                        if (!playerShot.IsDeleted()) {
                            newPlayerShots.Add(shot);
                        }
                    }

                    playerShots = newPlayerShots;
                }

            }
        }

        public void AddExplosion(float posX, float posY,
            float extentX, float extentY) {
            explosions.AddAnimation(
                new StationaryShape(posX, posY, extentX, extentY), explosionLength,
                new ImageStride(explosionLength / 8, explosionStrides));
        }

        public static GameRunning GetInstance() {
            return GameRunning.instance ?? (GameRunning.instance = new GameRunning());
        }
    }
}