using System;
using DIKUArcade.EventBus;
using DIKUArcade.State;
using Galaga_Exercise_3.GalagaStates;

namespace Galaga_Exercise_3 {
    public class StateMachine : IGameEventProcessor<object> {
        public StateMachine() {
            GalagaBus.GetBus().Subscribe(GameEventType.GameStateEvent, this);
            GalagaBus.GetBus().Subscribe(GameEventType.InputEvent, this);
            ActiveState = MainMenu.GetInstance();
            ActiveState.InitializeGameState();
        }

        public IGameState ActiveState { get; private set; }


        public void ProcessEvent(GameEventType eventType, GameEvent<object> gameEvent) {
            if (eventType == GameEventType.GameStateEvent) {
                switch (gameEvent.Parameter1) {
                case "GAME_RUNNING":
                    SwitchState(GameStateType.GameRunning);
                    break;
                case "MAIN_MENU":
                    GameRunning.GetInstance().InitializeGameState();
                    SwitchState(GameStateType.MainMenu);
                    break;
                case "GAME_PAUSED":
                    SwitchState(GameStateType.GamePaused);
                    break;
                default:
                    throw new Exception("Attempted to change to unrecognized state, bad parameter");
                }
            } else if (eventType == GameEventType.InputEvent) {
                ActiveState.HandleKeyEvent(gameEvent.Message, gameEvent.Parameter1);
            }
        }

        private void SwitchState(GameStateType stateType) {
            switch (stateType) {
            case GameStateType.GameRunning:
                ActiveState = GameRunning.GetInstance();
                break;
            case GameStateType.MainMenu:
                ActiveState = MainMenu.GetInstance();
                ActiveState.InitializeGameState();
                break;
            case GameStateType.GamePaused:
                ActiveState = GamePaused.GetInstance();
                ActiveState.InitializeGameState();
                break;
            default:
                throw new Exception("StateType not recognized");
            }
        }
    }
}