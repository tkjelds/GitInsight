﻿namespace Galaga_Exercise_3 {
    internal class Program {
        public static void Main(string[] args) {
             Game galaga = new Game();
            galaga.GameLoop();
        }
    }
}