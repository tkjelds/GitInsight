using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;

namespace Galaga_Exercise_3 {
    namespace GalagaEntities {
        public class Enemy : Entity {
            public Enemy(DynamicShape shape, IBaseImage image, Vec2F startPos)
                : base(shape, image) {
                this.startPos = startPos;
            }

            public Vec2F startPos { get; }
        }
    }
}